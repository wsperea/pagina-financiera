import { createApp } from 'vue'
import App from './app.vue' // <--- Cambiado de App a app (minúscula)
import router from './router'

const app = createApp(App)

app.use(router)
app.mount('#app')