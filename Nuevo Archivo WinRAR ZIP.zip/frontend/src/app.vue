<template>
  <router-view />
</template>

<style>
/* Estilos básicos para que no haya márgenes raros */
body, html {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
}


</style>