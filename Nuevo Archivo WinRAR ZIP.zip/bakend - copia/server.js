const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'finanzas_app',
    port: 3306
});

db.connect(err => {
    if (err) {
        console.error('❌ Error MySQL:', err.message);
        return;
    }
    console.log('✅ Conectado a finanzas_app');
});

// --- 1. USUARIOS (Login/Logout/Registro) ---

app.post('/api/login', (req, res) => {
    const { correo, contraseña } = req.body;
    
    // Comparamos el correo y aplicamos SHA2 solo aquí para ver si coincide con lo guardado
    // Cambia esto en tu consulta SQL dentro de app.post('/api/login')
    const sql = "SELECT id, nombre, rol, estado FROM `finanzas_app`.`usuarios` WHERE correo = ? AND contraseña = SHA2(?, 256)";

    db.query(sql, [correo, contraseña], (err, results) => {
        if (err) {
            console.error("❌ Error en la consulta SQL:", err); // Esto te dirá el error real en la terminal
            return res.status(500).json({ error: "Error en el servidor", detalle: err.message });
        }
        
        if (results.length > 0) {
            const usuario = results[0];
            // Actualizar estado a activo
            db.query('UPDATE usuarios SET estado = "activo" WHERE id = ?', [usuario.id]);
            
            res.status(200).json({
                id: usuario.id,
                nombre: usuario.nombre,
                rol: usuario.rol,
                estado: 'activo'
            });
        } else {
            res.status(401).json({ error: "Correo o contraseña incorrectos" });
        }
    });
});

app.post('/api/registrar', (req, res) => {
    const { nombre, correo, contraseña } = req.body;

    if (!nombre || !correo || !contraseña) {
        return res.status(400).json({ error: "Todos los campos son obligatorios" });
    }

    const sql = `INSERT INTO usuarios (nombre, correo, contraseña, rol, estado) VALUES (?, ?, SHA2(?, 256), 'usuario', 'inactivo')`;

    db.query(sql, [nombre, correo, contraseña], (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ error: "El correo ya está registrado" });
            }
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ mensaje: "Usuario registrado con éxito", id: result.insertId });
    });
});

app.post('/api/logout', (req, res) => {
    const { usuario_id } = req.body;
    if (!usuario_id) return res.status(400).json({ error: "ID requerido" });
    db.query('UPDATE usuarios SET estado = "inactivo" WHERE id = ?', [usuario_id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: "Sesión cerrada" });
    });
});


// --- RUTA AGREGADA PARA CONFIGURACIÓN ---
app.put('/api/usuario/actualizar/:id', (req, res) => {
    const { id } = req.params;
    const { nombre, correo, contraseña_actual, contraseña_nueva } = req.body;

    // Primero verificamos si el usuario existe y la contraseña actual es correcta
    const sqlCheck = `SELECT * FROM usuarios WHERE id = ? AND contraseña = SHA2(?, 256)`;
    
    db.query(sqlCheck, [id, contraseña_actual], (err, results) => {
        if (err) return res.status(500).json({ error: "Error en la base de datos" });
        if (results.length === 0) {
            return res.status(401).json({ error: "La contraseña actual es incorrecta" });
        }

        // Si se envió una contraseña nueva, la actualizamos; si no, solo nombre y correo
        let sqlUpdate;
        let params;

        if (contraseña_nueva) {
            sqlUpdate = `UPDATE usuarios SET nombre = ?, correo = ?, contraseña = SHA2(?, 256) WHERE id = ?`;
            params = [nombre, correo, contraseña_nueva, id];
        } else {
            sqlUpdate = `UPDATE usuarios SET nombre = ?, correo = ? WHERE id = ?`;
            params = [nombre, correo, id];
        }

        db.query(sqlUpdate, params, (errUpdate) => {
            if (errUpdate) {
                if (errUpdate.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: "El correo ya está en uso" });
                return res.status(500).json({ error: "Error al actualizar los datos" });
            }
            res.json({ mensaje: "¡Cambios guardados con éxito!" });
        });
    });
});

// --- 2. MOVIMIENTOS / TRANSACCIONES ---

app.get('/api/resumen/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;
    const sql = `
        SELECT 
            IFNULL(SUM(CASE WHEN tipo = 'ingreso' THEN monto ELSE 0 END), 0) AS ingresos,
            IFNULL(SUM(CASE WHEN tipo = 'gasto' THEN monto ELSE 0 END), 0) AS gastos
        FROM transacciones 
        WHERE usuario_id = ?`;

    db.query(sql, [usuario_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results[0]);
    });
});

app.get('/api/movimientos/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;
    const sql = `SELECT id, tipo, monto, descripcion, fecha, categoria_id 
                 FROM transacciones WHERE usuario_id = ? ORDER BY fecha DESC`;
    db.query(sql, [usuario_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/movimientos', (req, res) => {
    const { usuario_id, tipo, categoria_id, monto, descripcion, nombre_ingreso } = req.body;
    const detalle = nombre_ingreso || descripcion;
    const sql = `INSERT INTO transacciones (usuario_id, tipo, categoria_id, monto, descripcion) VALUES (?, ?, ?, ?, ?)`;
    db.query(sql, [usuario_id, tipo, categoria_id, monto, detalle], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.status(201).json({ mensaje: "Guardado", id: result.insertId });
    });
});

app.put('/api/movimientos/:id', (req, res) => {
    const { id } = req.params;
    const { tipo, categoria_id, monto, descripcion, nombre_ingreso } = req.body;
    const detalle = nombre_ingreso || descripcion || 'Sin detalle';
    const sql = `UPDATE transacciones SET tipo = ?, categoria_id = ?, monto = ?, descripcion = ? WHERE id = ?`;
    
    db.query(sql, [tipo, categoria_id, monto, detalle, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.json({ mensaje: "Actualizado correctamente" });
    });
});

app.delete('/api/movimientos/:id', (req, res) => {
    db.query('DELETE FROM transacciones WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: "Eliminado correctamente" });
    });
});

// --- 3. METAS ---

app.get('/api/metas/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;
    db.query('SELECT * FROM metas WHERE usuario_id = ?', [usuario_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/metas', (req, res) => {
    const { id, usuario_id, nombre, monto_objetivo, monto_actual, fecha_limite } = req.body;
    const ahorro = parseFloat(monto_actual) || 0;
    const meta = parseFloat(monto_objetivo) || 0;
    const fecha = fecha_limite || new Date().toISOString().slice(0, 10);

    if (id) {
        const sqlUpdate = `UPDATE metas SET nombre = ?, monto_objetivo = ?, monto_actual = ?, fecha_limite = ? WHERE id = ? AND usuario_id = ?`;
        db.query(sqlUpdate, [nombre, meta, ahorro, fecha, id, usuario_id], (err) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.json({ mensaje: "Meta actualizada." });
        });
    } else {
        const sqlInsert = `INSERT INTO metas (usuario_id, nombre, monto_objetivo, monto_actual, fecha_limite) VALUES (?, ?, ?, ?, ?)`;
        db.query(sqlInsert, [usuario_id, nombre, meta, ahorro, fecha], (err, result) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.status(201).json({ mensaje: "Meta creada.", id: result.insertId });
        });
    }
});

app.delete('/api/metas/:id', (req, res) => {
    db.query('DELETE FROM metas WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: "Meta eliminada" });
    });
});

// --- 4. PRESUPUESTOS (CON ARREGLOS) ---

app.get('/api/presupuestos/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;
    const sql = `SELECT p.*, c.nombre as categoria_nombre FROM presupuestos p JOIN categorias c ON p.categoria_id = c.id WHERE p.usuario_id = ?`;
    db.query(sql, [usuario_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/presupuestos', (req, res) => {
    const { id, usuario_id, categoria_id, monto_limite, monto_actual, periodo } = req.body;
    
    // ARREGLO: Validación de datos para evitar Error 500 por nulos
    if (!usuario_id || !categoria_id) {
        return res.status(400).json({ error: "usuario_id y categoria_id son requeridos" });
    }

    if (id) {
        const sqlUpdate = `UPDATE presupuestos SET categoria_id = ?, monto_limite = ?, monto_actual = ?, periodo = ? WHERE id = ? AND usuario_id = ?`;
        db.query(sqlUpdate, [categoria_id, monto_limite, monto_actual || 0, periodo || 'mensual', id, usuario_id], (err) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.json({ mensaje: "Presupuesto actualizado" });
        });
    } else {
        const sqlInsert = `INSERT INTO presupuestos (usuario_id, categoria_id, monto_limite, monto_actual, periodo) VALUES (?, ?, ?, ?, ?)`;
        db.query(sqlInsert, [usuario_id, categoria_id, monto_limite, monto_actual || 0, periodo || 'mensual'], (err, result) => {
            if (err) return res.status(500).json({ error: err.sqlMessage });
            res.status(201).json({ mensaje: "Presupuesto creado", id: result.insertId });
        });
    }
});

// ARREGLO: Nueva ruta para eliminar presupuestos
app.delete('/api/presupuestos/:id', (req, res) => {
    db.query('DELETE FROM presupuestos WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: "Presupuesto eliminado correctamente" });
    });
});

// --- 5. RECURRENTES ---

app.get('/api/recurrentes/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;
    const sql = `SELECT r.*, c.nombre as categoria_nombre FROM transacciones_recurrentes r JOIN categorias c ON r.categoria_id = c.id WHERE r.usuario_id = ?`;
    db.query(sql, [usuario_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
});

app.post('/api/recurrentes/pagar', (req, res) => {
    const { usuario_id, categoria_id, monto, descripcion, recurrente_id } = req.body;
    const sqlGasto = `INSERT INTO transacciones (usuario_id, tipo, categoria_id, monto, descripcion) VALUES (?, 'gasto', ?, ?, ?)`;
    db.query(sqlGasto, [usuario_id, categoria_id, monto, descripcion], (err) => {
        if (err) return res.status(500).json({ error: "Error al registrar" });
        const sqlUpdateRecurrente = `UPDATE transacciones_recurrentes SET pago = pago + ?, pagado = IF(pago + ? >= monto, 1, 0) WHERE id = ?`;
        db.query(sqlUpdateRecurrente, [monto, monto, recurrente_id], (err2) => {
            if (err2) return res.status(500).json({ error: "Error al actualizar" });
            res.json({ mensaje: "Aporte registrado" });
        });
    });
});

// --- NUEVAS RUTAS PARA CREAR Y EDITAR RECURRENTES ---

// Crear nuevo gasto recurrente
app.post('/api/recurrentes', (req, res) => {
    const { usuario_id, categoria_id, monto, frecuencia, fecha_inicio, descripcion } = req.body;
    const sql = `INSERT INTO transacciones_recurrentes 
                 (usuario_id, categoria_id, monto, frecuencia, fecha_inicio, descripcion, pago, pagado) 
                 VALUES (?, ?, ?, ?, ?, ?, 0, 0)`;
    
    db.query(sql, [usuario_id, categoria_id, monto, frecuencia, fecha_inicio, descripcion], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.status(201).json({ mensaje: "Recurrente creado", id: result.insertId });
    });
});

// Editar un gasto recurrente existente
app.put('/api/recurrentes/:id', (req, res) => {
    const { id } = req.params;
    const { categoria_id, monto, frecuencia, fecha_inicio, descripcion } = req.body;
    const sql = `UPDATE transacciones_recurrentes 
                 SET categoria_id = ?, monto = ?, frecuencia = ?, fecha_inicio = ?, descripcion = ? 
                 WHERE id = ?`;

    db.query(sql, [categoria_id, monto, frecuencia, fecha_inicio, descripcion, id], (err, result) => {
        if (err) return res.status(500).json({ error: err.sqlMessage });
        res.json({ mensaje: "Recurrente actualizado correctamente" });
    });
});

// Ruta para eliminar (Asegúrate de que ya la tienes o agrégala)
app.delete('/api/recurrentes/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM transacciones_recurrentes WHERE id = ?', [id], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ mensaje: "Gasto recurrente eliminado correctamente" });
    });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`));